(() => {
  'use strict';

  /*
   * 숨길 대상
   * 1) AI 모드 기록
   * 2) 새 대화목록
   *
   * Google DOM의 class/jsuid 값은 자주 바뀌므로
   * aria-label을 우선 기준으로 사용합니다.
   */

  const TARGETS = [
    'button[aria-label="AI 모드 기록"]',
    'button[aria-label="새 대화목록"]'
  ];

  const SELECTOR = TARGETS.join(',');

  function hide(el) {
    if (!(el instanceof HTMLElement)) return;

    el.style.setProperty('display', 'none', 'important');
    el.style.setProperty('visibility', 'hidden', 'important');
    el.style.setProperty('opacity', '0', 'important');
    el.style.setProperty('pointer-events', 'none', 'important');
    el.setAttribute('aria-hidden', 'true');
  }

  function scan(root) {
    if (!(root instanceof Document || root instanceof Element)) return;

    if (root instanceof Element && root.matches(SELECTOR)) {
      hide(root);
    }

    const nodes = root.querySelectorAll?.(SELECTOR);
    if (nodes) nodes.forEach(hide);
  }

  function installStyle() {
    if (document.getElementById('__hide_contents_css')) return;

    const style = document.createElement('style');
    style.id = '__hide_contents_css';

    style.textContent = `
      button[aria-label="AI 모드 기록"],
      button[aria-label="새 대화목록"] {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }
    `;

    const parent = document.head || document.documentElement;
    if (parent) parent.appendChild(style);
  }

  function start() {
    installStyle();
    scan(document);

    const root = document.documentElement;
    if (!root) return;

    const observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        if (m.type === 'childList') {
          for (const node of m.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              scan(node);
            }
          }
        } else if (m.type === 'attributes') {
          const el = m.target;
          if (el instanceof Element) {
            if (el.matches(SELECTOR)) {
              hide(el);
            } else {
              scan(el);
            }
          }
        }
      }
    });

    observer.observe(root, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['aria-label', 'style', 'class', 'jsname']
    });

    // Google가 렌더링 후 다시 표시하는 경우를 대비해 반복 확인
    const timer = setInterval(() => {
      scan(document);
    }, 500);

    window.addEventListener('pagehide', () => clearInterval(timer), { once: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
